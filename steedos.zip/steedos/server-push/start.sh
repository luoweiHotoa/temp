thin start --port 2000 -t 3600
