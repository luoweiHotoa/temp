class Push_message
	include MongoMapper::Document
	
	# 主键标识(必填)
	key :_id, ObjectId, :required => true
	# 消息标题(必填)
	key :alertTitle, String, :required => true
	# 消息摘要(必填)
	key :alert_summary, String, :required => true
	# 消息内容(必填)
	key :alert, String
	# 连接
	key :href,String
	# 用户id
	key :user, String, :required => true
	# 每个App在Push时的唯一标记
	key :push_topic,String, :required => true
	# 应用圈圈中显示的数量
	key :badge, Integer
	# 声音，默认"default"
	key :sound, String :default => "default"
end