thin start --port 6000 -d 
