thin start --port 7000 -d
