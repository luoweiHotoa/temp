thin stop --port 7000 
