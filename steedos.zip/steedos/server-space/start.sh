thin start --port 3000
