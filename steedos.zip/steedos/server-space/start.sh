thin start -d --port 3000
