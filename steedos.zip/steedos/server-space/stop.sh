thin stop --port 3000 
