thin stop --port 2600
