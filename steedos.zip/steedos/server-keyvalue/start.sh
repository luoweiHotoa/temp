# gem install thin

thin start --port 2600
