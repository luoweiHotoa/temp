# gem install thin

thin start -d --port 2600
