# gem install thin

thin stop --port 2300