# gem install thin

thin start --port 2300 -d
