thin stop --port 4000 
