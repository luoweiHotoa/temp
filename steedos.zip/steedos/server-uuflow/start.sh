thin start --port 4000 -d 
