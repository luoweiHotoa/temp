thin start --port 4000
